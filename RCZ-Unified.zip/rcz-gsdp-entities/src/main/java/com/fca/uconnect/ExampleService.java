package com.psa.rcz;

import org.springframework.stereotype.Service;

@Service
public class ExampleService {
    public String getModuleName() {
        return "rcz-alarm working!";
    }
}